import { Report, Severity, ReportType } from '../types';

/**
 * Priority levels:
 * 1 = Critical/Immediate - respond immediately
 * 2 = High - respond next
 * 3 = Medium - schedule after critical sites
 * 4 = Low - investigate pattern for longer-term fix
 * 5 = Routine - maintenance scheduling
 */

export interface PriorityAnalysis {
  priority: number;
  priorityLabel: string;
  reasoning: string[];
  estimatedResponse: string;
}

/**
 * Determines priority for City Engineers based on multiple factors
 */
export function determineCityEngineerPriority(report: Report): PriorityAnalysis {
  const reasoning: string[] = [];
  let priorityScore = 0;
  
  const descLower = report.description.toLowerCase();
  const locationLower = report.location.toLowerCase();
  
  // RULE 1: Flooded intersection → Priority 1 (Critical)
  const intersectionKeywords = ['intersection', 'crossroad', 'junction'];
  const floodedKeywords = ['flooded', 'flooding', 'submerged', 'impassable', 'deep water'];
  
  const isFlooded = floodedKeywords.some(k => descLower.includes(k));
  const isIntersection = intersectionKeywords.some(k => locationLower.includes(k));
  
  if (isFlooded && isIntersection) {
    priorityScore = 100;
    reasoning.push('Flooded intersection detected - immediate response required');
  }
  
  // RULE 2: Overflow near residential sidewalk → Priority 2 (High)
  const overflowKeywords = ['overflow', 'overflowing', 'spilling'];
  const residentialKeywords = ['residential', 'subdivision', 'neighborhood', 'barangay'];
  const sidewalkKeywords = ['sidewalk', 'walkway', 'pedestrian'];
  
  const isOverflow = overflowKeywords.some(k => descLower.includes(k));
  const isResidential = residentialKeywords.some(k => locationLower.includes(k) || descLower.includes(k));
  const isSidewalk = sidewalkKeywords.some(k => descLower.includes(k) || locationLower.includes(k));
  
  if (isOverflow && (isResidential || isSidewalk) && priorityScore < 100) {
    priorityScore = 80;
    reasoning.push('Overflow near residential/sidewalk area - high priority');
  }
  
  // RULE 3: Slow drain in park → Priority 3 (Medium)
  const slowDrainKeywords = ['slow drain', 'poor drainage', 'slow', 'pooling'];
  const parkKeywords = ['park', 'playground', 'recreation'];
  
  const isSlowDrain = slowDrainKeywords.some(k => descLower.includes(k));
  const isPark = parkKeywords.some(k => locationLower.includes(k));
  
  if (isSlowDrain && isPark && priorityScore < 80) {
    priorityScore = 60;
    reasoning.push('Slow drainage in park area - medium priority');
  }
  
  // RULE 4: Recurrent blockage near commercial zone → Priority 4 (Low - Investigation)
  const blockageKeywords = ['blocked', 'blockage', 'clogged', 'recurrent', 'recurring', 'repeated'];
  const commercialKeywords = ['commercial', 'business', 'market', 'plaza', 'mall', 'shop'];
  
  const isBlockage = blockageKeywords.some(k => descLower.includes(k));
  const isCommercial = commercialKeywords.some(k => locationLower.includes(k));
  
  if (isBlockage && isCommercial && priorityScore < 60) {
    priorityScore = 40;
    reasoning.push('Recurrent blockage in commercial area - investigation needed');
  }
  
  // RULE 5: Routine debris buildup → Priority 5 (Routine)
  const debrisKeywords = ['debris', 'leaves', 'trash', 'garbage', 'buildup', 'accumulation'];
  const routineKeywords = ['routine', 'regular', 'maintenance', 'cleaning'];
  
  const isDebris = debrisKeywords.some(k => descLower.includes(k));
  const isRoutine = routineKeywords.some(k => descLower.includes(k));
  
  if ((isDebris || isRoutine) && priorityScore < 40) {
    priorityScore = 20;
    reasoning.push('Routine debris/maintenance issue - scheduled maintenance');
  }
  
  // Severity impact on priority
  if (report.severity === 'Severe') {
    priorityScore += 30;
    reasoning.push('Severe severity level detected');
  } else if (report.severity === 'Moderate') {
    priorityScore += 15;
    reasoning.push('Moderate severity level');
  }
  
  // Report type impact
  if (report.reportType === 'Flooding') {
    priorityScore += 20;
    reasoning.push('Flooding report type');
  } else if (report.reportType === 'Drainage') {
    priorityScore += 10;
    reasoning.push('Drainage issue');
  }
  
  // Critical infrastructure locations
  const criticalInfra = ['hospital', 'school', 'fire station', 'police', 'highway', 'main road', 'bridge'];
  const hasCriticalInfra = criticalInfra.some(k => locationLower.includes(k));
  
  if (hasCriticalInfra) {
    priorityScore += 25;
    reasoning.push('Located near critical infrastructure');
  }
  
  // Determine final priority level
  let priority: number;
  let priorityLabel: string;
  let estimatedResponse: string;
  
  if (priorityScore >= 90) {
    priority = 1;
    priorityLabel = 'Critical';
    estimatedResponse = 'Immediate response (within 2 hours)';
  } else if (priorityScore >= 70) {
    priority = 2;
    priorityLabel = 'High';
    estimatedResponse = 'Next priority (within 24 hours)';
  } else if (priorityScore >= 50) {
    priority = 3;
    priorityLabel = 'Medium';
    estimatedResponse = 'Schedule after critical sites (2-3 days)';
  } else if (priorityScore >= 30) {
    priority = 4;
    priorityLabel = 'Low';
    estimatedResponse = 'Investigation/pattern analysis (1 week)';
  } else {
    priority = 5;
    priorityLabel = 'Routine';
    estimatedResponse = 'Maintenance scheduling (as available)';
  }
  
  return {
    priority,
    priorityLabel,
    reasoning,
    estimatedResponse
  };
}

/**
 * Determines priority for Barangay Officials (handles Minor and Moderate only)
 * Severe cases are automatically routed to City Engineers (not visible to Barangay)
 */
export function determineBarangayPriority(report: Report): PriorityAnalysis {
  // Severe cases should never reach here as they're filtered out for Barangay Officials
  // But adding check for safety
  if (report.severity === 'Severe') {
    return {
      priority: 1,
      priorityLabel: 'Critical',
      reasoning: ['Severe case - routed to City Engineer'],
      estimatedResponse: 'Handled by City Engineer'
    };
  }
  
  // Get the city engineer priority first
  const cityPriority = determineCityEngineerPriority(report);
  
  // Adjust priority to be less severe for barangay level
  let barangayPriority = cityPriority.priority;
  let priorityLabel = cityPriority.priorityLabel;
  let estimatedResponse = cityPriority.estimatedResponse;
  const reasoning = [...cityPriority.reasoning];
  
  // If city priority is Critical (1), barangay makes it High (2)
  if (cityPriority.priority === 1) {
    barangayPriority = 2;
    priorityLabel = 'High';
    estimatedResponse = 'Urgent attention (within 12 hours)';
    reasoning.push('✓ Adjusted from Critical to High for barangay level');
  }
  // If city priority is High (2), barangay makes it Medium (3)
  else if (cityPriority.priority === 2) {
    barangayPriority = 3;
    priorityLabel = 'Medium';
    estimatedResponse = 'Attention needed (within 2 days)';
    reasoning.push('✓ Adjusted from High to Medium for barangay level');
  }
  // Lower priorities remain the same
  else {
    reasoning.push('✓ Priority maintained at barangay level');
  }
  
  return {
    priority: barangayPriority,
    priorityLabel,
    reasoning,
    estimatedResponse
  };
}

/**
 * Get priority badge color and styling
 */
export function getPriorityBadgeClass(priority: number): string {
  switch (priority) {
    case 1:
      return 'bg-red-100 text-red-800 border-red-300';
    case 2:
      return 'bg-orange-100 text-orange-800 border-orange-300';
    case 3:
      return 'bg-yellow-100 text-yellow-800 border-yellow-300';
    case 4:
      return 'bg-blue-100 text-blue-800 border-blue-300';
    case 5:
      return 'bg-gray-100 text-gray-800 border-gray-300';
    default:
      return 'bg-gray-100 text-gray-800 border-gray-300';
  }
}

/**
 * Get priority label from number
 */
export function getPriorityLabel(priority: number): string {
  switch (priority) {
    case 1:
      return 'Critical';
    case 2:
      return 'High';
    case 3:
      return 'Medium';
    case 4:
      return 'Low';
    case 5:
      return 'Routine';
    default:
      return 'Unassigned';
  }
}
