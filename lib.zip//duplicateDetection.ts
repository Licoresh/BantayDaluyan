import { Report, ReportType } from '../types';
import { calculateDistance, Coordinates } from './geocoding';

export interface DuplicateReport {
  report: Report;
  distance: number; // in meters
  similarity: number; // 0-100 percentage
}

export interface DuplicateAnalysis {
  isDuplicate: boolean;
  duplicates: DuplicateReport[];
  message: string;
}

// Check if two strings are similar using simple word matching
function calculateStringSimilarity(str1: string, str2: string): number {
  const words1 = str1.toLowerCase().split(/\s+/);
  const words2 = str2.toLowerCase().split(/\s+/);
  
  let matchCount = 0;
  for (const word1 of words1) {
    if (word1.length < 3) continue; // Skip short words
    for (const word2 of words2) {
      if (word1 === word2 || word1.includes(word2) || word2.includes(word1)) {
        matchCount++;
        break;
      }
    }
  }
  
  const avgLength = (words1.length + words2.length) / 2;
  return (matchCount / avgLength) * 100;
}

// Detect duplicate reports based on location, type, time, and description
export function detectDuplicates(
  newReport: {
    reportType: ReportType;
    description: string;
    latitude: string;
    longitude: string;
  },
  existingReports: Report[]
): DuplicateAnalysis {
  const duplicates: DuplicateReport[] = [];
  const newCoords: Coordinates = {
    latitude: parseFloat(newReport.latitude),
    longitude: parseFloat(newReport.longitude)
  };
  
  const now = new Date();
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  
  for (const existingReport of existingReports) {
    // Skip completed reports older than 30 days
    if (existingReport.status === 'Completed' && existingReport.dateFiled < thirtyDaysAgo) {
      continue;
    }
    
    const existingCoords: Coordinates = {
      latitude: existingReport.latitude,
      longitude: existingReport.longitude
    };
    
    // Calculate distance in kilometers, convert to meters
    const distanceKm = calculateDistance(newCoords, existingCoords);
    const distanceMeters = distanceKm * 1000;
    
    // Only consider reports within 100 meters
    if (distanceMeters > 100) {
      continue;
    }
    
    let similarity = 0;
    
    // Same report type: +40 points
    if (existingReport.reportType === newReport.reportType) {
      similarity += 40;
    }
    
    // Distance scoring: closer = more similar (up to 30 points)
    // 0-20m: 30 points, 20-50m: 20 points, 50-100m: 10 points
    if (distanceMeters <= 20) {
      similarity += 30;
    } else if (distanceMeters <= 50) {
      similarity += 20;
    } else {
      similarity += 10;
    }
    
    // Description similarity: up to 30 points
    const descSimilarity = calculateStringSimilarity(
      newReport.description,
      existingReport.description
    );
    similarity += (descSimilarity / 100) * 30;
    
    // Consider it a potential duplicate if similarity >= 60%
    if (similarity >= 60) {
      duplicates.push({
        report: existingReport,
        distance: Math.round(distanceMeters),
        similarity: Math.round(similarity)
      });
    }
  }
  
  // Sort by similarity (highest first)
  duplicates.sort((a, b) => b.similarity - a.similarity);
  
  let message = '';
  if (duplicates.length === 0) {
    message = 'No duplicate reports found in this area.';
  } else if (duplicates.length === 1) {
    message = `Found 1 similar report within ${duplicates[0].distance}m. Please review before submitting.`;
  } else {
    message = `Found ${duplicates.length} similar reports nearby. Please review to avoid duplicates.`;
  }
  
  return {
    isDuplicate: duplicates.length > 0,
    duplicates: duplicates.slice(0, 3), // Return top 3 duplicates
    message
  };
}

// Format distance for display
export function formatDistance(meters: number): string {
  if (meters < 1000) {
    return `${meters}m away`;
  } else {
    return `${(meters / 1000).toFixed(1)}km away`;
  }
}

// Calculate time difference for display
export function getTimeSince(date: Date): string {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);
  
  if (diffMins < 60) {
    return `${diffMins} minute${diffMins !== 1 ? 's' : ''} ago`;
  } else if (diffHours < 24) {
    return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
  } else {
    return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
  }
}
