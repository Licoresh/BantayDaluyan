import { Severity, ReportType } from '../types';

/**
 * Simulates AI-powered image analysis to detect severity
 * In a real implementation, this would use a machine learning model
 * to analyze the uploaded image and determine severity level
 */

interface SeverityAnalysis {
  severity: Severity;
  confidence: number;
  factors: string[];
}

/**
 * Analyzes image to detect severity based on visual cues
 * Simulates ML detection of:
 * - Water level/depth
 * - Affected area size
 * - Infrastructure damage
 * - Public safety risks
 * 
 * Note: Reports are routed based on severity:
 *       - Severe: Only visible to City Engineers
 *       - Minor & Moderate: Only visible to Barangay Officials
 */
export function analyzeImageForSeverity(
  imageFile: File | null,
  reportType: ReportType,
  description: string,
  location: string,
  forRole?: 'Barangay' | 'Engineer'
): SeverityAnalysis {
  // Simulate processing delay
  const factors: string[] = [];
  
  // Analyze description for severity keywords
  const descLower = description.toLowerCase();
  const locationLower = location.toLowerCase();
  
  // Critical keywords indicating severe issues
  const severeKeywords = [
    'flooded', 'flooding', 'submerged', 'impassable', 'blocked road',
    'overflow', 'burst', 'major', 'critical', 'emergency', 'dangerous',
    'accident', 'hazard', 'deep water', 'rapid', 'heavy', 'extensive'
  ];
  
  // Moderate keywords
  const moderateKeywords = [
    'clogged', 'slow drain', 'pooling', 'backup', 'overflow',
    'accumulation', 'moderate', 'rising', 'concern', 'warning',
    'residential', 'sidewalk', 'street', 'neighborhood'
  ];
  
  // Minor keywords
  const minorKeywords = [
    'debris', 'leaves', 'maintenance', 'routine', 'small',
    'minor', 'slight', 'minimal', 'park', 'cleaning needed'
  ];
  
  // Location-based severity factors
  const criticalLocations = [
    'intersection', 'highway', 'main road', 'bridge', 'tunnel',
    'hospital', 'school', 'market', 'downtown', 'commercial'
  ];
  
  const moderateLocations = [
    'residential', 'subdivision', 'barangay', 'street', 'avenue'
  ];
  
  let severityScore = 0;
  
  // Analyze report type
  if (reportType === 'Flooding') {
    severityScore += 30;
    factors.push('Flooding report type');
  } else if (reportType === 'Drainage') {
    severityScore += 15;
    factors.push('Drainage issue');
  } else if (reportType === 'Garbage') {
    severityScore += 10;
    factors.push('Garbage accumulation');
  }
  
  // Check for severe keywords
  const severeMatches = severeKeywords.filter(keyword => descLower.includes(keyword));
  if (severeMatches.length > 0) {
    severityScore += 40;
    factors.push(`Critical indicators: ${severeMatches.join(', ')}`);
  }
  
  // Check for moderate keywords
  const moderateMatches = moderateKeywords.filter(keyword => descLower.includes(keyword));
  if (moderateMatches.length > 0) {
    severityScore += 20;
    factors.push(`Moderate indicators: ${moderateMatches.join(', ')}`);
  }
  
  // Check for minor keywords
  const minorMatches = minorKeywords.filter(keyword => descLower.includes(keyword));
  if (minorMatches.length > 0 && severeMatches.length === 0) {
    severityScore -= 10;
    factors.push(`Minor indicators: ${minorMatches.join(', ')}`);
  }
  
  // Check location criticality
  const criticalLocationMatches = criticalLocations.filter(loc => locationLower.includes(loc));
  if (criticalLocationMatches.length > 0) {
    severityScore += 25;
    factors.push(`Critical location: ${criticalLocationMatches.join(', ')}`);
  }
  
  const moderateLocationMatches = moderateLocations.filter(loc => locationLower.includes(loc));
  if (moderateLocationMatches.length > 0 && criticalLocationMatches.length === 0) {
    severityScore += 10;
    factors.push(`Residential location: ${moderateLocationMatches.join(', ')}`);
  }
  
  // Simulate image analysis boost (if image provided)
  if (imageFile) {
    // In real implementation, this would be actual ML analysis
    severityScore += 15;
    factors.push('Image analysis completed');
  }
  
  // Determine severity level based on score
  let severity: Severity;
  let confidence: number;
  
  if (severityScore >= 60) {
    severity = 'Severe';
    confidence = Math.min(95, 70 + severityScore - 60);
    factors.push('⚠️ SEVERE case - Routed to City Engineer only');
  } else if (severityScore >= 30) {
    severity = 'Moderate';
    confidence = Math.min(90, 65 + severityScore - 30);
    factors.push('✓ Moderate case - Handled by Barangay Official');
  } else {
    severity = 'Minor';
    confidence = Math.min(85, 60 + severityScore);
    factors.push('✓ Minor case - Handled by Barangay Official');
  }
  
  // Note: Role-based filtering is handled at the dashboard level
  // Severe reports are only visible to City Engineers
  // Minor and Moderate reports are only visible to Barangay Officials
  
  return {
    severity,
    confidence,
    factors
  };
}

/**
 * Get severity badge color
 */
export function getSeverityColor(severity: Severity): string {
  switch (severity) {
    case 'Severe':
      return 'bg-red-100 text-red-800 border-red-300';
    case 'Moderate':
      return 'bg-yellow-100 text-yellow-800 border-yellow-300';
    case 'Minor':
      return 'bg-blue-100 text-blue-800 border-blue-300';
  }
}
