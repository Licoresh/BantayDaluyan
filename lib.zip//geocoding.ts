// Simulated reverse geocoding for Iligan City
// In production, this would use a real geocoding API like Google Maps, Mapbox, or Nominatim

interface Coordinates {
  latitude: number;
  longitude: number;
}

interface Address {
  street: string;
  barangay: string;
  city: string;
  fullAddress: string;
}

// Sample Iligan City locations with their approximate coordinates
const iliganLocations = [
  { lat: 8.2280, lng: 124.2452, street: 'Quezon Avenue', barangay: 'Poblacion' },
  { lat: 8.2305, lng: 124.2389, street: 'Roxas Avenue', barangay: 'Tibanga' },
  { lat: 8.2195, lng: 124.2505, street: 'Pala-o Road', barangay: 'Pala-o' },
  { lat: 8.2410, lng: 124.2478, street: 'Mahayahay Street', barangay: 'Mahayahay' },
  { lat: 8.2345, lng: 124.2421, street: 'Andres Bonifacio Avenue', barangay: 'Tambacan' },
  { lat: 8.2268, lng: 124.2512, street: 'Aguinaldo Street', barangay: 'Buhanginan' },
  { lat: 8.2156, lng: 124.2445, street: 'General Santos Drive', barangay: 'Tubod' },
  { lat: 8.2389, lng: 124.2356, street: 'Macapagal Highway', barangay: 'Kiwalan' },
  { lat: 8.2421, lng: 124.2512, street: 'Rizal Avenue', barangay: 'Palao' },
  { lat: 8.2198, lng: 124.2389, street: 'Badelles Street', barangay: 'Saray' },
  { lat: 8.2312, lng: 124.2501, street: 'Del Pilar Street', barangay: 'Del Carmen' },
  { lat: 8.2378, lng: 124.2434, street: 'Chavez Street', barangay: 'San Miguel' },
  { lat: 8.2245, lng: 124.2467, street: 'Zamora Street', barangay: 'Sta. Filomena' },
  { lat: 8.2289, lng: 124.2398, street: 'Luna Street', barangay: 'Sta. Elena' },
  { lat: 8.2334, lng: 124.2489, street: 'Bonifacio Drive', barangay: 'Santiago' },
];

// Calculate distance between two coordinates using Haversine formula
function calculateDistance(coord1: Coordinates, coord2: Coordinates): number {
  const R = 6371; // Earth's radius in kilometers
  const dLat = toRad(coord2.latitude - coord1.latitude);
  const dLon = toRad(coord2.longitude - coord1.longitude);
  
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(coord1.latitude)) * Math.cos(toRad(coord2.latitude)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  
  return distance; // Returns distance in kilometers
}

function toRad(degrees: number): number {
  return degrees * (Math.PI / 180);
}

// Find the nearest location from our predefined list
export function reverseGeocode(coordinates: Coordinates): Address {
  let nearestLocation = iliganLocations[0];
  let minDistance = Infinity;
  
  // Find the nearest predefined location
  for (const location of iliganLocations) {
    const distance = calculateDistance(coordinates, { 
      latitude: location.lat, 
      longitude: location.lng 
    });
    
    if (distance < minDistance) {
      minDistance = distance;
      nearestLocation = location;
    }
  }
  
  // Generate address based on nearest location
  const fullAddress = `${nearestLocation.street}, Brgy. ${nearestLocation.barangay}, Iligan City`;
  
  return {
    street: nearestLocation.street,
    barangay: nearestLocation.barangay,
    city: 'Iligan City',
    fullAddress
  };
}

// Check if coordinates are within Iligan City bounds
export function isWithinIliganCity(coordinates: Coordinates): boolean {
  // Approximate bounds of Iligan City
  const bounds = {
    minLat: 8.15,
    maxLat: 8.35,
    minLng: 124.15,
    maxLng: 124.35
  };
  
  return (
    coordinates.latitude >= bounds.minLat &&
    coordinates.latitude <= bounds.maxLat &&
    coordinates.longitude >= bounds.minLng &&
    coordinates.longitude <= bounds.maxLng
  );
}

export { calculateDistance };
export type { Coordinates, Address };
