import { User, Report, BarangayAction, CityEngineerAction, Notification, ActivityLog } from '../types';

export const mockUsers: User[] = [
  {
    id: '1',
    fullname: 'Jolo Canete',
    email: 'jolo@example.com',
    password: 'password123',
    contactNumber: '+63 912 345 6789',
    address: '123 Quezon Ave, Iligan City',
    role: 'Resident',
    createdAt: new Date('2025-01-15')
  },
  {
    id: '2',
    fullname: 'Bari Imam',
    email: 'bari@barangay.gov',
    password: 'password123',
    contactNumber: '+63 923 456 7890',
    address: 'Barangay Santiago, Iligan City',
    role: 'Barangay Official',
    createdAt: new Date('2025-01-10')
  },
  {
    id: '3',
    fullname: 'Jazleen Septimo',
    email: 'jazleen@cityeng.gov',
    password: 'password123',
    contactNumber: '+63 934 567 8901',
    address: 'City Engineering Office, Iligan City',
    role: 'City Engineer',
    createdAt: new Date('2025-01-05')
  },
  {
    id: '4',
    fullname: 'Admin User',
    email: 'admin@system.gov',
    password: 'admin123',
    contactNumber: '+63 945 678 9012',
    address: 'City Hall, Iligan City',
    role: 'Admin',
    createdAt: new Date('2025-01-01')
  }
];

export const mockReports: Report[] = [
  {
    id: 'RPT001',
    userId: '1',
    reportType: 'Drainage',
    description: 'Clogged drainage causing water accumulation on the street',
    location: 'Corner of Quezon Ave and Roxas Ave, Poblacion',
    latitude: 8.2280,
    longitude: 124.2452,
    severity: 'Severe',
    photoUrl: 'https://images.unsplash.com/photo-1672401497662-c1721770129a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800',
    status: 'Ongoing',
    dateFiled: new Date('2025-10-20'),
    assignedTo: '2',
    priority: 1
  },
  {
    id: 'RPT002',
    userId: '1',
    reportType: 'Flooding',
    description: 'Street flooding during heavy rain, water level reaches 1 foot',
    location: 'Tibanga Highway near Public Market',
    latitude: 8.2310,
    longitude: 124.2435,
    severity: 'Severe',
    photoUrl: 'https://images.unsplash.com/photo-1737303260803-2d187e42faeb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800',
    status: 'Forwarded',
    dateFiled: new Date('2025-10-18'),
    assignedTo: '3',
    priority: 2
  },
  {
    id: 'RPT003',
    userId: '1',
    reportType: 'Garbage',
    description: 'Uncollected garbage blocking drainage system',
    location: 'Palao Road, Barangay Palao',
    latitude: 8.2265,
    longitude: 124.2470,
    severity: 'Minor',
    photoUrl: 'https://images.unsplash.com/photo-1761252986819-eca07a0eeb91?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800',
    status: 'Completed',
    dateFiled: new Date('2025-10-10'),
    dateResolved: new Date('2025-10-15'),
    feedback: 'Issue resolved quickly. The team was very professional and thorough. Thank you!',
    feedbackRating: 5,
    feedbackDate: new Date('2025-10-16')
  },
  {
    id: 'RPT004',
    userId: '1',
    reportType: 'Drainage',
    description: 'Broken drainage cover creating safety hazard',
    location: 'MacArthur Highway near MSU-IIT',
    latitude: 8.2295,
    longitude: 124.2415,
    severity: 'Severe',
    photoUrl: 'https://images.unsplash.com/photo-1740484708120-86a447d6ca6c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800',
    status: 'Pending',
    dateFiled: new Date('2025-10-25'),
    priority: 1
  },
  {
    id: 'RPT005',
    userId: '1',
    reportType: 'Others',
    description: 'Tree roots damaging underground drainage pipes',
    location: 'Del Pilar Street, Barangay Poblacion',
    latitude: 8.2250,
    longitude: 124.2460,
    severity: 'Moderate',
    photoUrl: 'https://images.unsplash.com/photo-1657069344364-db3781b8dcf1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800',
    status: 'Pending',
    dateFiled: new Date('2025-10-26')
  },
  {
    id: 'RPT006',
    userId: '1',
    reportType: 'Flooding',
    description: 'Major flooding during heavy rainfall, affecting residential area',
    location: 'Sabayle Street, Barangay Tipanoy',
    latitude: 8.2240,
    longitude: 124.2480,
    severity: 'Severe',
    photoUrl: 'https://images.unsplash.com/photo-1537202763866-085b7b468d5e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800',
    status: 'Forwarded',
    dateFiled: new Date('2025-10-27'),
    assignedTo: '3'
  }
];

export const mockBarangayActions: BarangayAction[] = [
  {
    id: 'BA001',
    reportId: 'RPT001',
    officialId: '2',
    remarks: 'Inspection completed. Requires heavy equipment for clearing.',
    actionDate: new Date('2025-10-21'),
    status: 'Ongoing'
  }
];

export const mockEngineerActions: CityEngineerAction[] = [
  {
    id: 'CE001',
    reportId: 'RPT002',
    engineerId: '3',
    assignedTeam: 'Team Alpha - Drainage Division',
    remarks: 'Site assessment completed. Scheduling repair work.',
    status: 'Ongoing',
    priority: 2
  }
];

export const mockNotifications: Notification[] = [
  {
    id: 'N001',
    userId: '1',
    reportId: 'RPT001',
    message: 'Your report RPT001 status has been updated to Ongoing',
    isRead: false,
    createdAt: new Date('2025-10-21T10:30:00')
  },
  {
    id: 'N002',
    userId: '1',
    reportId: 'RPT003',
    message: 'Your report RPT003 has been marked as Completed',
    isRead: false,
    createdAt: new Date('2025-10-15T14:20:00')
  },
  {
    id: 'N003',
    userId: '1',
    reportId: 'RPT002',
    message: 'Your report RPT002 has been forwarded to City Engineer',
    isRead: true,
    createdAt: new Date('2025-10-19T09:15:00')
  },
  {
    id: 'N004',
    userId: '2',
    reportId: 'RPT001',
    message: 'New report assigned to you: RPT001',
    isRead: false,
    createdAt: new Date('2025-10-20T08:00:00')
  },
  {
    id: 'N005',
    userId: '3',
    reportId: 'RPT006',
    message: 'New high-priority flooding report forwarded to you: RPT006',
    isRead: false,
    createdAt: new Date('2025-10-27T09:30:00')
  },
  {
    id: 'N006',
    userId: '3',
    reportId: 'RPT002',
    message: 'Report RPT002 requires priority level assignment',
    isRead: false,
    createdAt: new Date('2025-10-26T15:45:00')
  },
  {
    id: 'N007',
    userId: '4',
    reportId: 'RPT006',
    message: 'New report filed in the system: RPT006 - Severe flooding in Barangay Tipanoy',
    isRead: false,
    createdAt: new Date('2025-10-27T09:30:00')
  },
  {
    id: 'N008',
    userId: '4',
    reportId: 'RPT004',
    message: 'Report RPT004 has been pending for 2 days - requires attention',
    isRead: false,
    createdAt: new Date('2025-10-27T08:00:00')
  }
];

export const mockActivityLogs: ActivityLog[] = [
  {
    id: 'L001',
    userId: '1',
    action: 'Filed Report',
    reportId: 'RPT001',
    timestamp: new Date('2025-10-20T08:30:00'),
    details: 'Report filed for drainage issue at Corner of Quezon Ave and Roxas Ave, Poblacion'
  },
  {
    id: 'L002',
    userId: '2',
    action: 'Updated Status',
    reportId: 'RPT001',
    timestamp: new Date('2025-10-21T10:30:00'),
    details: 'Changed status from Pending to Ongoing'
  },
  {
    id: 'L003',
    userId: '2',
    action: 'Added Remarks',
    reportId: 'RPT001',
    timestamp: new Date('2025-10-21T10:35:00'),
    details: 'Added inspection remarks and action notes'
  },
  {
    id: 'L004',
    userId: '1',
    action: 'Filed Report',
    reportId: 'RPT002',
    timestamp: new Date('2025-10-18T14:20:00'),
    details: 'Report filed for flooding issue at Tibanga Highway near Public Market'
  },
  {
    id: 'L005',
    userId: '2',
    action: 'Forwarded Report',
    reportId: 'RPT002',
    timestamp: new Date('2025-10-19T09:15:00'),
    details: 'Forwarded report to City Engineer for assessment'
  },
  {
    id: 'L006',
    userId: '3',
    action: 'Assigned Team',
    reportId: 'RPT002',
    timestamp: new Date('2025-10-19T11:00:00'),
    details: 'Assigned Team Alpha - Drainage Division to handle the report'
  },
  {
    id: 'L007',
    userId: '4',
    action: 'User Created',
    timestamp: new Date('2025-10-15T09:00:00'),
    details: 'New user registered: maria@example.com (Resident)'
  }
];
