import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Report } from '../types';
import { mockReports } from '../lib/mockData';
import { FileText, MapPin, Calendar, AlertTriangle, Plus, Eye, ArrowUpDown, MessageSquare, Star } from 'lucide-react';
import { MapView } from './MapView';
import { FeedbackDialog } from './FeedbackDialog';

interface ResidentDashboardProps {
  userId: string;
  onViewReport: (report: Report) => void;
  onFileNewReport: () => void;
}

export function ResidentDashboard({ userId, onViewReport, onFileNewReport }: ResidentDashboardProps) {
  const [sortBy, setSortBy] = useState<string>('date-desc');
  const [feedbackDialogOpen, setFeedbackDialogOpen] = useState(false);
  const [selectedReportForFeedback, setSelectedReportForFeedback] = useState<Report | null>(null);
  const userReports = mockReports.filter(r => r.userId === userId);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Ongoing': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'Forwarded': return 'bg-purple-100 text-purple-800 border-purple-200';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'Severe':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'Moderate':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Minor':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const stats = {
    total: userReports.length,
    pending: userReports.filter(r => r.status === 'Pending').length,
    ongoing: userReports.filter(r => r.status === 'Ongoing' || r.status === 'Forwarded').length,
    completed: userReports.filter(r => r.status === 'Completed').length
  };

  // Sorting function
  const getSortedReports = () => {
    const sorted = [...userReports];
    
    switch (sortBy) {
      case 'date-desc':
        return sorted.sort((a, b) => b.dateFiled.getTime() - a.dateFiled.getTime());
      case 'date-asc':
        return sorted.sort((a, b) => a.dateFiled.getTime() - b.dateFiled.getTime());
      case 'status-pending':
        return sorted.sort((a, b) => {
          const statusOrder = { 'Pending': 0, 'Ongoing': 1, 'Forwarded': 2, 'Completed': 3 };
          return (statusOrder[a.status as keyof typeof statusOrder] || 4) - (statusOrder[b.status as keyof typeof statusOrder] || 4);
        });
      case 'status-completed':
        return sorted.sort((a, b) => {
          const statusOrder = { 'Completed': 0, 'Forwarded': 1, 'Ongoing': 2, 'Pending': 3 };
          return (statusOrder[a.status as keyof typeof statusOrder] || 4) - (statusOrder[b.status as keyof typeof statusOrder] || 4);
        });
      case 'severity-high':
        return sorted.sort((a, b) => {
          const severityOrder = { 'Severe': 0, 'Moderate': 1, 'Minor': 2 };
          return (severityOrder[a.severity as keyof typeof severityOrder] || 3) - (severityOrder[b.severity as keyof typeof severityOrder] || 3);
        });
      case 'severity-low':
        return sorted.sort((a, b) => {
          const severityOrder = { 'Minor': 0, 'Moderate': 1, 'Severe': 2 };
          return (severityOrder[a.severity as keyof typeof severityOrder] || 3) - (severityOrder[b.severity as keyof typeof severityOrder] || 3);
        });
      case 'type':
        return sorted.sort((a, b) => a.reportType.localeCompare(b.reportType));
      default:
        return sorted;
    }
  };

  const sortedReports = getSortedReports();

  const handleProvideFeedback = (report: Report) => {
    setSelectedReportForFeedback(report);
    setFeedbackDialogOpen(true);
  };

  const handleSubmitFeedback = (reportId: string, feedback: string, rating: number) => {
    const report = mockReports.find(r => r.id === reportId);
    if (report) {
      report.feedback = feedback;
      report.feedbackRating = rating;
      report.feedbackDate = new Date();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl">My Reports</h2>
          <p className="text-gray-600">Track and manage your reports</p>
        </div>
        <Button onClick={onFileNewReport} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="h-4 w-4 mr-2" />
          File New Report
        </Button>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Reports</p>
                <p className="text-3xl mt-1">{stats.total}</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending</p>
                <p className="text-3xl mt-1">{stats.pending}</p>
              </div>
              <div className="bg-yellow-100 p-3 rounded-full">
                <AlertTriangle className="h-6 w-6 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">In Progress</p>
                <p className="text-3xl mt-1">{stats.ongoing}</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <Calendar className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Completed</p>
                <p className="text-3xl mt-1">{stats.completed}</p>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <FileText className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Map View */}
      <Card>
        <CardHeader>
          <CardTitle>Reports Map - Iligan City</CardTitle>
        </CardHeader>
        <CardContent>
          <MapView 
            reports={userReports} 
            onReportClick={onViewReport}
            height="500px"
          />
        </CardContent>
      </Card>

      {/* Reports List */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <CardTitle>Recent Reports</CardTitle>
            <div className="flex items-center gap-2">
              <ArrowUpDown className="h-4 w-4 text-gray-500" />
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="date-desc">Date (Newest First)</SelectItem>
                  <SelectItem value="date-asc">Date (Oldest First)</SelectItem>
                  <SelectItem value="status-pending">Status (Pending First)</SelectItem>
                  <SelectItem value="status-completed">Status (Completed First)</SelectItem>
                  <SelectItem value="severity-high">Severity (High to Low)</SelectItem>
                  <SelectItem value="severity-low">Severity (Low to High)</SelectItem>
                  <SelectItem value="type">Report Type (A-Z)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {userReports.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No reports filed yet</p>
                <Button onClick={onFileNewReport} variant="outline" className="mt-4">
                  File Your First Report
                </Button>
              </div>
            ) : (
              sortedReports.map(report => (
                <div 
                  key={report.id}
                  className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 hover:shadow-md transition-all"
                >
                  <div className="flex flex-col lg:flex-row gap-4">
                    {/* Image */}
                    <div className="flex-shrink-0">
                      {report.photoUrl ? (
                        <img 
                          src={report.photoUrl} 
                          alt="Report" 
                          className="w-full lg:w-32 h-32 object-cover rounded-lg"
                        />
                      ) : (
                        <div className="w-full lg:w-32 h-32 bg-gray-100 rounded-lg flex items-center justify-center">
                          <FileText className="h-8 w-8 text-gray-400" />
                        </div>
                      )}
                    </div>

                    {/* Content */}
                    <div className="flex-1 space-y-2">
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-medium">{report.id}</span>
                            <Badge variant="outline" className={getStatusColor(report.status)}>
                              {report.status}
                            </Badge>
                            <Badge variant="outline" className={getSeverityColor(report.severity)}>
                              {report.severity}
                            </Badge>
                            {report.status === 'Completed' && report.feedback && (
                              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300">
                                <Star className="h-3 w-3 mr-1 fill-green-600" />
                                Feedback Submitted
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-gray-600 mt-1">
                            {report.reportType}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => onViewReport(report)}
                            className="hover:bg-blue-50"
                          >
                            <Eye className="h-4 w-4 mr-2" />
                            View Details
                          </Button>
                          {report.status === 'Completed' && !report.feedback && (
                            <Button 
                              size="sm" 
                              onClick={() => handleProvideFeedback(report)}
                              className="bg-green-600 hover:bg-green-700 text-white"
                            >
                              <MessageSquare className="h-4 w-4 mr-2" />
                              Provide Feedback
                            </Button>
                          )}
                        </div>
                      </div>

                      <p className="text-gray-700">{report.description}</p>

                      <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {report.location}
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          Filed: {report.dateFiled.toLocaleDateString()}
                        </div>
                        {report.dateResolved && (
                          <div className="flex items-center gap-1 text-green-600">
                            <Calendar className="h-4 w-4" />
                            Resolved: {report.dateResolved.toLocaleDateString()}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Feedback Dialog */}
      {selectedReportForFeedback && (
        <FeedbackDialog
          open={feedbackDialogOpen}
          onClose={() => setFeedbackDialogOpen(false)}
          report={selectedReportForFeedback}
          onSubmit={handleSubmitFeedback}
        />
      )}
    </div>
  );
}
