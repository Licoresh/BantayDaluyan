import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Notification, Report } from '../types';
import { mockNotifications, mockReports } from '../lib/mockData';
import { Bell, BellOff, Check, Eye, Trash2 } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface NotificationsPanelProps {
  userId: string;
  onViewReport: (report: Report) => void;
}

export function NotificationsPanel({ userId, onViewReport }: NotificationsPanelProps) {
  const [notifications, setNotifications] = useState<Notification[]>(
    mockNotifications.filter(n => n.userId === userId)
  );

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const handleMarkAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(n => n.id === id ? { ...n, isRead: true } : n)
    );
    toast.success('Marked as read');
  };

  const handleMarkAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
    toast.success('All notifications marked as read');
  };

  const handleDelete = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
    toast.success('Notification deleted');
  };

  const handleViewReport = (notification: Notification) => {
    const report = mockReports.find(r => r.id === notification.reportId);
    if (report) {
      handleMarkAsRead(notification.id);
      onViewReport(report);
    }
  };

  const sortedNotifications = [...notifications].sort((a, b) => 
    b.createdAt.getTime() - a.createdAt.getTime()
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl flex items-center gap-2">
            <Bell className="h-6 w-6" />
            Notifications
          </h2>
          <p className="text-gray-600">
            {unreadCount > 0 ? `${unreadCount} unread notification${unreadCount > 1 ? 's' : ''}` : 'All caught up!'}
          </p>
        </div>
        {unreadCount > 0 && (
          <Button 
            variant="outline"
            onClick={handleMarkAllAsRead}
          >
            <Check className="h-4 w-4 mr-2" />
            Mark All as Read
          </Button>
        )}
      </div>

      <Card>
        <CardContent className="pt-6">
          {notifications.length === 0 ? (
            <div className="text-center py-12">
              <BellOff className="h-16 w-16 mx-auto mb-4 text-gray-300" />
              <p className="text-gray-500">No notifications yet</p>
              <p className="text-sm text-gray-400 mt-2">
                You'll be notified when there are updates to your reports
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {sortedNotifications.map(notification => (
                <div
                  key={notification.id}
                  className={`border rounded-lg p-4 transition-all ${
                    notification.isRead
                      ? 'border-gray-200 bg-white'
                      : 'border-blue-200 bg-blue-50'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    {/* Icon */}
                    <div className={`flex-shrink-0 mt-1 ${notification.isRead ? 'opacity-50' : ''}`}>
                      <div className={`p-2 rounded-full ${
                        notification.isRead ? 'bg-gray-100' : 'bg-blue-100'
                      }`}>
                        <Bell className={`h-5 w-5 ${
                          notification.isRead ? 'text-gray-500' : 'text-blue-600'
                        }`} />
                      </div>
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <p className={`${notification.isRead ? 'text-gray-700' : 'font-medium text-gray-900'}`}>
                          {notification.message}
                        </p>
                        {!notification.isRead && (
                          <Badge className="bg-blue-600 text-white flex-shrink-0">New</Badge>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-3 text-sm text-gray-500">
                        <span className="flex items-center gap-1">
                          <span>Report ID: {notification.reportId}</span>
                        </span>
                        <span>•</span>
                        <span>{notification.createdAt.toLocaleString()}</span>
                      </div>

                      {/* Actions */}
                      <div className="flex flex-wrap gap-2 mt-3">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleViewReport(notification)}
                          className="hover:bg-blue-50"
                        >
                          <Eye className="h-3 w-3 mr-1" />
                          View Report
                        </Button>
                        {!notification.isRead && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleMarkAsRead(notification.id)}
                          >
                            <Check className="h-3 w-3 mr-1" />
                            Mark as Read
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDelete(notification.id)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="h-3 w-3 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
