import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from './ui/alert-dialog';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { Label } from './ui/label';
import { mockUsers, mockReports, mockActivityLogs } from '../lib/mockData';
import { Users, FileText, Activity, CheckCircle, Search, Filter, Eye, UserCog, Edit, Trash2, AlertCircle } from 'lucide-react';
import { Report, UserRole, User } from '../types';
import { MapView } from './MapView';
import { toast } from 'sonner@2.0.3';

interface AdminDashboardProps {
  onViewReport: (report: Report) => void;
}

export function AdminDashboard({ onViewReport }: AdminDashboardProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [logFilter, setLogFilter] = useState('All');
  const [users, setUsers] = useState(mockUsers);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [newRole, setNewRole] = useState<UserRole>('Resident');
  const [isRoleDialogOpen, setIsRoleDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editFormData, setEditFormData] = useState({
    fullname: '',
    email: '',
    contactNumber: '',
    address: ''
  });
  const [editFormErrors, setEditFormErrors] = useState<Record<string, string>>({});

  const stats = {
    totalUsers: users.length,
    totalReports: mockReports.length,
    activeReports: mockReports.filter(r => r.status === 'Ongoing' || r.status === 'Forwarded').length,
    completedReports: mockReports.filter(r => r.status === 'Completed').length
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending': return 'bg-yellow-100 text-yellow-800';
      case 'Ongoing': return 'bg-blue-100 text-blue-800';
      case 'Completed': return 'bg-green-100 text-green-800';
      case 'Forwarded': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'Admin': return 'bg-red-100 text-red-800';
      case 'City Engineer': return 'bg-blue-100 text-blue-800';
      case 'Barangay Official': return 'bg-purple-100 text-purple-800';
      case 'Resident': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleRoleChange = () => {
    if (!selectedUser) return;
    
    setUsers(prevUsers => 
      prevUsers.map(user => 
        user.id === selectedUser.id 
          ? { ...user, role: newRole }
          : user
      )
    );
    
    toast.success(`Successfully changed ${selectedUser.fullname}'s role to ${newRole}`);
    setIsRoleDialogOpen(false);
    setSelectedUser(null);
  };

  const openRoleDialog = (user: User) => {
    setSelectedUser(user);
    setNewRole(user.role);
    setIsRoleDialogOpen(true);
  };

  const validateEditField = (field: string, value: string) => {
    let error = '';

    switch (field) {
      case 'fullname':
        if (!value.trim()) error = 'Full name is required';
        else if (value.trim().length < 3) error = 'Full name must be at least 3 characters';
        break;
      case 'email':
        if (!value) error = 'Email is required';
        else if (!/\S+@\S+\.\S+/.test(value)) error = 'Please enter a valid email address';
        break;
      case 'contactNumber':
        if (!value) error = 'Contact number is required';
        else if (!/^[+]?[\d\s()-]{10,}$/.test(value)) error = 'Please enter a valid contact number';
        break;
      case 'address':
        if (!value.trim()) error = 'Address is required';
        else if (value.trim().length < 10) error = 'Please enter a complete address';
        break;
    }

    setEditFormErrors(prev => ({ ...prev, [field]: error }));
    return !error;
  };

  const openEditDialog = (user: User) => {
    setSelectedUser(user);
    setEditFormData({
      fullname: user.fullname,
      email: user.email,
      contactNumber: user.contactNumber,
      address: user.address
    });
    setEditFormErrors({});
    setIsEditDialogOpen(true);
  };

  const handleEditUser = () => {
    if (!selectedUser) return;

    // Validate all fields
    const fields = ['fullname', 'email', 'contactNumber', 'address'];
    const validations = fields.map(field => validateEditField(field, editFormData[field as keyof typeof editFormData]));

    if (!validations.every(v => v)) {
      toast.error('Please fix the errors before saving');
      return;
    }

    setUsers(prevUsers => 
      prevUsers.map(user => 
        user.id === selectedUser.id 
          ? { ...user, ...editFormData }
          : user
      )
    );
    
    toast.success(`Successfully updated ${editFormData.fullname}'s information`);
    setIsEditDialogOpen(false);
    setSelectedUser(null);
  };

  const openDeleteDialog = (user: User) => {
    setSelectedUser(user);
    setIsDeleteDialogOpen(true);
  };

  const handleDeleteUser = () => {
    if (!selectedUser) return;
    
    setUsers(prevUsers => prevUsers.filter(user => user.id !== selectedUser.id));
    
    toast.success(`Successfully deleted user: ${selectedUser.fullname}`);
    setIsDeleteDialogOpen(false);
    setSelectedUser(null);
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.fullname.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === 'All' || user.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const filteredReports = mockReports.filter(report => {
    const matchesSearch = report.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         report.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         report.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || report.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const filteredLogs = mockActivityLogs.filter(log => {
    const matchesFilter = logFilter === 'All' || log.action.includes(logFilter);
    return matchesFilter;
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl">Admin Dashboard</h2>
        <p className="text-gray-600">System overview and management</p>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Users</p>
                <p className="text-3xl mt-1">{stats.totalUsers}</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Reports</p>
                <p className="text-3xl mt-1">{stats.totalReports}</p>
              </div>
              <div className="bg-purple-100 p-3 rounded-full">
                <FileText className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Reports</p>
                <p className="text-3xl mt-1">{stats.activeReports}</p>
              </div>
              <div className="bg-orange-100 p-3 rounded-full">
                <Activity className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Completed</p>
                <p className="text-3xl mt-1">{stats.completedReports}</p>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Map Overview */}
      <Card>
        <CardHeader>
          <CardTitle>All Reports Map - Iligan City</CardTitle>
        </CardHeader>
        <CardContent>
          <MapView 
            reports={mockReports} 
            onReportClick={onViewReport}
            height="500px"
          />
        </CardContent>
      </Card>

      {/* Tabs for different views */}
      <Card>
        <Tabs defaultValue="users" className="w-full">
          <CardHeader>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="users">User Management</TabsTrigger>
              <TabsTrigger value="reports">Report Logs</TabsTrigger>
              <TabsTrigger value="activity">Activity Logs</TabsTrigger>
            </TabsList>
          </CardHeader>

          <CardContent>
            {/* Users Tab */}
            <TabsContent value="users" className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search users by name or email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={roleFilter} onValueChange={setRoleFilter}>
                  <SelectTrigger className="w-full sm:w-48">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Roles</SelectItem>
                    <SelectItem value="Resident">Resident</SelectItem>
                    <SelectItem value="Barangay Official">Barangay Official</SelectItem>
                    <SelectItem value="City Engineer">City Engineer</SelectItem>
                    <SelectItem value="Admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Full Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Contact</TableHead>
                      <TableHead>Registered</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.map(user => (
                      <TableRow key={user.id}>
                        <TableCell>{user.fullname}</TableCell>
                        <TableCell className="text-sm text-gray-600">{user.email}</TableCell>
                        <TableCell>
                          <Badge className={getRoleBadgeColor(user.role)}>
                            {user.role}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">{user.contactNumber}</TableCell>
                        <TableCell className="text-sm text-gray-600">
                          {user.createdAt.toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => openEditDialog(user)}
                                    className="text-blue-600 hover:text-blue-700 hover:border-blue-300"
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Edit User</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>

                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => openRoleDialog(user)}
                                    className="text-purple-600 hover:text-purple-700 hover:border-purple-300"
                                  >
                                    <UserCog className="h-4 w-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Change Role</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>

                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => openDeleteDialog(user)}
                                    className="text-red-600 hover:text-red-700 hover:border-red-300"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Delete User</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            {/* Reports Tab */}
            <TabsContent value="reports" className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search reports by ID, description, or location..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-full sm:w-48">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Status</SelectItem>
                    <SelectItem value="Pending">Pending</SelectItem>
                    <SelectItem value="Ongoing">Ongoing</SelectItem>
                    <SelectItem value="Forwarded">Forwarded</SelectItem>
                    <SelectItem value="Completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Report ID</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Severity</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date Filed</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredReports.map(report => (
                      <TableRow key={report.id}>
                        <TableCell>{report.id}</TableCell>
                        <TableCell className="text-sm">{report.reportType}</TableCell>
                        <TableCell className="text-sm text-gray-600">{report.location}</TableCell>
                        <TableCell>
                          <Badge className={
                            report.severity === 'Severe' ? 'bg-red-100 text-red-800' : 
                            report.severity === 'Moderate' ? 'bg-orange-100 text-orange-800' :
                            'bg-green-100 text-green-800'
                          }>
                            {report.severity}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(report.status)}>
                            {report.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-gray-600">
                          {report.dateFiled.toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => onViewReport(report)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            {/* Activity Logs Tab */}
            <TabsContent value="activity" className="space-y-4">
              <div className="flex justify-end">
                <Select value={logFilter} onValueChange={setLogFilter}>
                  <SelectTrigger className="w-full sm:w-64">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Activities</SelectItem>
                    <SelectItem value="Filed">Filed Reports</SelectItem>
                    <SelectItem value="Updated">Status Updates</SelectItem>
                    <SelectItem value="Forwarded">Forwarded Reports</SelectItem>
                    <SelectItem value="User">User Activities</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-3">
                {filteredLogs.map(log => {
                  const user = users.find(u => u.id === log.userId);
                  return (
                    <div key={log.id} className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-all">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium">{user?.fullname}</span>
                            <Badge variant="outline" className={getRoleBadgeColor(user?.role || '')}>
                              {user?.role}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-700 mb-1">
                            <span className="text-blue-600">{log.action}</span>
                            {log.reportId && <span className="text-gray-500"> • Report: {log.reportId}</span>}
                          </p>
                          <p className="text-sm text-gray-600">{log.details}</p>
                        </div>
                        <div className="text-xs text-gray-500 whitespace-nowrap">
                          {log.timestamp.toLocaleString()}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </TabsContent>
          </CardContent>
        </Tabs>
      </Card>

      {/* Edit User Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit User Information</DialogTitle>
            <DialogDescription>
              Update information for <strong>{selectedUser?.fullname}</strong>
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-fullname">Full Name *</Label>
              <Input
                id="edit-fullname"
                value={editFormData.fullname}
                onChange={(e) => {
                  setEditFormData(prev => ({ ...prev, fullname: e.target.value }));
                  if (editFormErrors.fullname) validateEditField('fullname', e.target.value);
                }}
                onBlur={() => validateEditField('fullname', editFormData.fullname)}
                className={editFormErrors.fullname ? 'border-red-500' : ''}
              />
              {editFormErrors.fullname && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="h-3 w-3" />
                  {editFormErrors.fullname}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-email">Email Address *</Label>
              <Input
                id="edit-email"
                type="email"
                value={editFormData.email}
                onChange={(e) => {
                  setEditFormData(prev => ({ ...prev, email: e.target.value }));
                  if (editFormErrors.email) validateEditField('email', e.target.value);
                }}
                onBlur={() => validateEditField('email', editFormData.email)}
                className={editFormErrors.email ? 'border-red-500' : ''}
              />
              {editFormErrors.email && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="h-3 w-3" />
                  {editFormErrors.email}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-contact">Contact Number *</Label>
              <Input
                id="edit-contact"
                value={editFormData.contactNumber}
                onChange={(e) => {
                  setEditFormData(prev => ({ ...prev, contactNumber: e.target.value }));
                  if (editFormErrors.contactNumber) validateEditField('contactNumber', e.target.value);
                }}
                onBlur={() => validateEditField('contactNumber', editFormData.contactNumber)}
                className={editFormErrors.contactNumber ? 'border-red-500' : ''}
              />
              {editFormErrors.contactNumber && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="h-3 w-3" />
                  {editFormErrors.contactNumber}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-address">Address *</Label>
              <Input
                id="edit-address"
                value={editFormData.address}
                onChange={(e) => {
                  setEditFormData(prev => ({ ...prev, address: e.target.value }));
                  if (editFormErrors.address) validateEditField('address', e.target.value);
                }}
                onBlur={() => validateEditField('address', editFormData.address)}
                className={editFormErrors.address ? 'border-red-500' : ''}
              />
              {editFormErrors.address && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="h-3 w-3" />
                  {editFormErrors.address}
                </p>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleEditUser} className="bg-blue-600 hover:bg-blue-700">
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Change Role Dialog */}
      <Dialog open={isRoleDialogOpen} onOpenChange={setIsRoleDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Change User Role</DialogTitle>
            <DialogDescription>
              Update the role for <strong>{selectedUser?.fullname}</strong>
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Current Role</Label>
              <div>
                <Badge className={getRoleBadgeColor(selectedUser?.role || '')}>
                  {selectedUser?.role}
                </Badge>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="newRole">New Role</Label>
              <Select value={newRole} onValueChange={(value) => setNewRole(value as UserRole)}>
                <SelectTrigger id="newRole">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Resident">Resident</SelectItem>
                  <SelectItem value="Barangay Official">Barangay Official</SelectItem>
                  <SelectItem value="City Engineer">City Engineer</SelectItem>
                  <SelectItem value="Admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
              <p className="text-sm text-amber-800">
                ⚠️ Changing a user's role will immediately affect their access permissions and dashboard view.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRoleDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleRoleChange} className="bg-blue-600 hover:bg-blue-700">
              Confirm Change
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete User Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete User</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete <strong>{selectedUser?.fullname}</strong>? This action cannot be undone and will permanently remove the user and all associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 my-2">
            <p className="text-sm text-red-800 flex items-center gap-2">
              <AlertCircle className="h-4 w-4 flex-shrink-0" />
              <span>This will delete all reports and activities associated with this user.</span>
            </p>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteUser}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete User
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
