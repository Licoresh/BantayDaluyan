import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { ReportType, Severity } from '../types';
import { MapPin, Upload, CheckCircle, AlertCircle, ArrowLeft, Brain, Zap, AlertTriangle, FileText, Calendar } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { analyzeImageForSeverity, getSeverityColor } from '../lib/severityDetection';
import { Badge } from './ui/badge';
import { reverseGeocode, isWithinIliganCity } from '../lib/geocoding';
import { detectDuplicates, formatDistance, getTimeSince, DuplicateAnalysis } from '../lib/duplicateDetection';
import { mockReports } from '../lib/mockData';

interface ReportFilingScreenProps {
  userId: string;
  onBack: () => void;
}

export function ReportFilingScreen({ userId, onBack }: ReportFilingScreenProps) {
  const [formData, setFormData] = useState({
    reportType: '' as ReportType | '',
    description: '',
    location: '',
    latitude: '',
    longitude: '',
    severity: '' as Severity | '',
    photoFile: null as File | null
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [photoPreview, setPhotoPreview] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [severityAnalysis, setSeverityAnalysis] = useState<{
    severity: Severity;
    confidence: number;
    factors: string[];
  } | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [gpsLoading, setGpsLoading] = useState(true);
  const [gpsError, setGpsError] = useState<string>('');
  const [duplicateAnalysis, setDuplicateAnalysis] = useState<DuplicateAnalysis | null>(null);
  const [showDuplicateWarning, setShowDuplicateWarning] = useState(false);
  const [confirmSubmitDuplicate, setConfirmSubmitDuplicate] = useState(false);

  // Auto-capture GPS coordinates and reverse geocode on mount
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const coords = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          };
          
          // Check if within Iligan City
          if (!isWithinIliganCity(coords)) {
            setGpsLoading(false);
            setGpsError('Location is outside Iligan City bounds');
            toast.error('Location Error', {
              description: 'This system only accepts reports from Iligan City.'
            });
            return;
          }
          
          // Reverse geocode to get address
          const address = reverseGeocode(coords);
          
          setFormData(prev => ({
            ...prev,
            latitude: coords.latitude.toFixed(6),
            longitude: coords.longitude.toFixed(6),
            location: address.fullAddress
          }));
          setGpsLoading(false);
          toast.success('Location detected automatically', {
            description: address.fullAddress
          });
        },
        (error) => {
          setGpsLoading(false);
          setGpsError('Unable to access GPS. Please enable location services.');
          toast.error('GPS access denied', {
            description: 'Please enable location services to file a report.'
          });
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        }
      );
    } else {
      setGpsLoading(false);
      setGpsError('GPS not supported by this browser');
      toast.error('GPS not available');
    }
  }, []);

  // Auto-analyze severity and check for duplicates when key fields change
  useEffect(() => {
    if (formData.reportType && formData.description.length >= 20 && formData.location && formData.latitude && formData.longitude) {
      setIsAnalyzing(true);
      
      // Simulate AI processing delay
      const timer = setTimeout(() => {
        // Severity analysis
        const analysis = analyzeImageForSeverity(
          formData.photoFile,
          formData.reportType as ReportType,
          formData.description,
          formData.location
        );
        setSeverityAnalysis(analysis);
        setFormData(prev => ({ ...prev, severity: analysis.severity }));
        setIsAnalyzing(false);
        toast.success(`AI Analysis Complete: ${analysis.severity} severity detected`);
        
        // Duplicate detection
        const duplicateCheck = detectDuplicates(
          {
            reportType: formData.reportType as ReportType,
            description: formData.description,
            latitude: formData.latitude,
            longitude: formData.longitude
          },
          mockReports
        );
        
        setDuplicateAnalysis(duplicateCheck);
        
        if (duplicateCheck.isDuplicate) {
          setShowDuplicateWarning(true);
          toast.warning('Potential duplicate detected', {
            description: duplicateCheck.message
          });
        }
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [formData.reportType, formData.description, formData.location, formData.photoFile, formData.latitude, formData.longitude]);

  const validateField = (field: string, value: string) => {
    let error = '';

    switch (field) {
      case 'reportType':
        if (!value) error = 'Please select a report type';
        break;
      case 'description':
        if (!value.trim()) error = 'Description is required';
        else if (value.trim().length < 20) error = 'Please provide a detailed description (at least 20 characters)';
        break;
      case 'location':
        if (!value.trim()) error = 'Location is required';
        break;
      // Removed severity validation - now auto-detected
    }

    setErrors(prev => ({ ...prev, [field]: error }));
    return !error;
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      validateField(field, value);
    }
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setErrors(prev => ({ ...prev, photo: 'File size must be less than 5MB' }));
        return;
      }
      
      setFormData(prev => ({ ...prev, photoFile: file }));
      setErrors(prev => ({ ...prev, photo: '' }));
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRefreshLocation = () => {
    if (navigator.geolocation) {
      setGpsLoading(true);
      setGpsError('');
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const coords = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          };
          
          // Check if within Iligan City
          if (!isWithinIliganCity(coords)) {
            setGpsLoading(false);
            setGpsError('Location is outside Iligan City bounds');
            toast.error('Location Error', {
              description: 'This system only accepts reports from Iligan City.'
            });
            return;
          }
          
          // Reverse geocode to get address
          const address = reverseGeocode(coords);
          
          setFormData(prev => ({
            ...prev,
            latitude: coords.latitude.toFixed(6),
            longitude: coords.longitude.toFixed(6),
            location: address.fullAddress
          }));
          setGpsLoading(false);
          toast.success('Location refreshed', {
            description: address.fullAddress
          });
        },
        (error) => {
          setGpsLoading(false);
          setGpsError('Unable to get GPS location');
          toast.error('Unable to refresh location');
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        }
      );
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check GPS coordinates
    if (!formData.latitude || !formData.longitude) {
      toast.error('GPS coordinates are required', {
        description: 'Please wait for GPS to be captured or click Refresh GPS.'
      });
      return;
    }
    
    // Check for duplicates and require confirmation
    if (duplicateAnalysis?.isDuplicate && !confirmSubmitDuplicate) {
      toast.warning('Please confirm this is not a duplicate', {
        description: 'Review similar reports below and confirm to submit.'
      });
      return;
    }
    
    const fields = ['reportType', 'description', 'location'];
    const validations = fields.map(field => validateField(field, formData[field as keyof typeof formData] as string));

    if (validations.every(v => v) && formData.severity) {
      setIsSubmitting(true);
      
      // Simulate API call
      setTimeout(() => {
        setIsSubmitting(false);
        setSubmitted(true);
        toast.success('Report submitted successfully!');
        
        setTimeout(() => {
          onBack();
        }, 2000);
      }, 1500);
    } else if (!formData.severity) {
      toast.error('Please wait for severity analysis to complete');
    }
  };

  if (submitted) {
    return (
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardContent className="pt-12 pb-12 text-center">
            <div className="flex justify-center mb-6">
              <div className="bg-green-100 p-4 rounded-full">
                <CheckCircle className="h-12 w-12 text-green-600" />
              </div>
            </div>
            <h3 className="text-xl mb-2">Report Submitted Successfully!</h3>
            <p className="text-gray-600 mb-6">
              Your report has been received and will be reviewed by the appropriate authorities.
            </p>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <p className="text-sm">
                <span>You will receive notifications about the status of your report via the notifications panel.</span>
              </p>
            </div>
            <Button onClick={onBack}>Return to Dashboard</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      <Button variant="ghost" onClick={onBack} className="mb-4">
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Dashboard
      </Button>

      <Card>
        <CardHeader>
          <CardTitle>File a Report</CardTitle>
          <CardDescription>
            Report drainage, flooding, or related issues in your area
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* GPS Info Banner */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="space-y-2">
                <p className="text-sm">
                  <strong>Automatic Location Detection:</strong> Your GPS coordinates and address are being captured automatically. This ensures accurate positioning and helps detect duplicate reports in the same area.
                </p>
                {duplicateAnalysis && !duplicateAnalysis.isDuplicate && formData.location && (
                  <p className="text-xs text-green-700 flex items-center gap-1">
                    <CheckCircle className="h-3 w-3" />
                    No duplicate reports found in this area
                  </p>
                )}
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Report Type */}
            <div className="space-y-2">
              <Label htmlFor="reportType">Report Type *</Label>
              <Select 
                value={formData.reportType} 
                onValueChange={(value) => handleInputChange('reportType', value as ReportType)}
              >
                <SelectTrigger className={errors.reportType ? 'border-red-500' : ''}>
                  <SelectValue placeholder="Select type of issue" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Drainage">Drainage Issue</SelectItem>
                  <SelectItem value="Flooding">Flooding</SelectItem>
                  <SelectItem value="Garbage">Garbage Blocking Drainage</SelectItem>
                  <SelectItem value="Others">Others</SelectItem>
                </SelectContent>
              </Select>
              {errors.reportType && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="h-3 w-3" />
                  {errors.reportType}
                </p>
              )}
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                placeholder="Provide detailed description of the issue (minimum 20 characters)..."
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                onBlur={() => validateField('description', formData.description)}
                rows={4}
                className={errors.description ? 'border-red-500' : ''}
              />
              <div className="flex justify-between text-xs">
                {errors.description ? (
                  <p className="text-red-600 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" />
                    {errors.description}
                  </p>
                ) : (
                  <p className="text-gray-500">
                    {formData.description.length} / 20 minimum characters
                  </p>
                )}
              </div>
            </div>

            {/* Location - Auto-filled from GPS */}
            <div className="space-y-2">
              <Label htmlFor="location">Location (Auto-detected from GPS) *</Label>
              <Input
                id="location"
                placeholder="Detecting location..."
                value={formData.location}
                readOnly
                className="bg-gray-50 cursor-not-allowed"
              />
              {formData.location && (
                <p className="text-xs text-gray-600 flex items-center gap-1">
                  <CheckCircle className="h-3 w-3 text-green-600" />
                  Address automatically detected from your GPS coordinates
                </p>
              )}
              {errors.location && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="h-3 w-3" />
                  {errors.location}
                </p>
              )}
            </div>

            {/* Auto-Captured GPS Coordinates */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>GPS Coordinates (Auto-Captured)</Label>
                <Button 
                  type="button" 
                  variant="outline"
                  size="sm"
                  onClick={handleRefreshLocation}
                  disabled={gpsLoading}
                >
                  <MapPin className="h-4 w-4 mr-2" />
                  {gpsLoading ? 'Getting GPS...' : 'Refresh GPS'}
                </Button>
              </div>
              
              {gpsError ? (
                <Alert className="border-red-200 bg-red-50">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-800">
                    {gpsError}
                  </AlertDescription>
                </Alert>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="latitude" className="text-xs text-gray-600">Latitude</Label>
                      <Input
                        id="latitude"
                        value={formData.latitude || 'Detecting...'}
                        readOnly
                        className="bg-gray-50 cursor-not-allowed"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="longitude" className="text-xs text-gray-600">Longitude</Label>
                      <Input
                        id="longitude"
                        value={formData.longitude || 'Detecting...'}
                        readOnly
                        className="bg-gray-50 cursor-not-allowed"
                      />
                    </div>
                  </div>
                  {formData.latitude && formData.longitude && (
                    <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                      <p className="text-sm text-green-800 flex items-center gap-2">
                        <CheckCircle className="h-4 w-4" />
                        GPS location captured: {formData.latitude}, {formData.longitude}
                      </p>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Map Placeholder */}
            {(formData.latitude && formData.longitude) && (
              <div className="bg-gray-100 rounded-lg p-8 text-center border-2 border-dashed border-gray-300">
                <MapPin className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                <p className="text-sm text-gray-600">
                  Location: {formData.latitude}, {formData.longitude}
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  Map preview would appear here in production
                </p>
              </div>
            )}

            {/* Automated Severity Analysis */}
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Label>AI Severity Analysis</Label>
                <Badge variant="outline" className="gap-1">
                  <Brain className="h-3 w-3" />
                  Automated
                </Badge>
              </div>
              
              {isAnalyzing && (
                <div className="border-2 border-blue-200 bg-blue-50 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <div className="animate-spin">
                      <Zap className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-sm text-blue-900">Analyzing severity...</p>
                      <p className="text-xs text-blue-700">AI is evaluating the report details</p>
                    </div>
                  </div>
                </div>
              )}
              
              {severityAnalysis && !isAnalyzing && (
                <div className={`border-2 rounded-lg p-4 ${
                  severityAnalysis.severity === 'Severe' ? 'border-red-200 bg-red-50' :
                  severityAnalysis.severity === 'Moderate' ? 'border-yellow-200 bg-yellow-50' :
                  'border-blue-200 bg-blue-50'
                }`}>
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm border ${getSeverityColor(severityAnalysis.severity)}`}>
                          {severityAnalysis.severity}
                        </span>
                        <span className="text-xs text-gray-600">
                          {severityAnalysis.confidence}% confidence
                        </span>
                      </div>
                      <p className="text-xs text-gray-600 mt-2">
                        This severity level has been automatically determined based on AI analysis
                      </p>
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <p className="text-xs text-gray-700">Analysis factors:</p>
                    <ul className="text-xs text-gray-600 space-y-1">
                      {severityAnalysis.factors.map((factor, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="text-blue-600 mt-0.5">•</span>
                          <span>{factor}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
              
              {!formData.reportType || !formData.description || !formData.location ? (
                <Alert>
                  <AlertDescription className="text-sm">
                    Please fill in Report Type, Description, and Location to enable AI severity analysis
                  </AlertDescription>
                </Alert>
              ) : null}
            </div>

            {/* Duplicate Detection Warning */}
            {showDuplicateWarning && duplicateAnalysis && duplicateAnalysis.isDuplicate && (
              <div className="space-y-3">
                <Alert className="border-orange-300 bg-orange-50">
                  <AlertTriangle className="h-5 w-5 text-orange-600" />
                  <AlertTitle className="text-orange-900">Potential Duplicate Reports Detected</AlertTitle>
                  <AlertDescription className="text-orange-800">
                    {duplicateAnalysis.message} Please review the similar reports below to avoid submitting duplicates.
                  </AlertDescription>
                </Alert>

                <div className="space-y-3">
                  <p className="text-sm">Similar reports found:</p>
                  {duplicateAnalysis.duplicates.map((dup, idx) => (
                    <Card key={idx} className="border-orange-200 bg-orange-50/50">
                      <CardContent className="pt-4">
                        <div className="space-y-2">
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <Badge className={getSeverityColor(dup.report.severity)}>
                                  {dup.report.severity}
                                </Badge>
                                <Badge variant="outline" className="text-xs">
                                  {dup.similarity}% match
                                </Badge>
                              </div>
                              <p className="text-sm">
                                <strong>{dup.report.reportType}</strong> - {dup.report.location}
                              </p>
                            </div>
                            <Badge 
                              variant="outline"
                              className={`${
                                dup.report.status === 'Completed' ? 'bg-green-100 text-green-800 border-green-200' :
                                dup.report.status === 'Ongoing' ? 'bg-blue-100 text-blue-800 border-blue-200' :
                                'bg-gray-100 text-gray-800 border-gray-200'
                              }`}
                            >
                              {dup.report.status}
                            </Badge>
                          </div>
                          
                          <p className="text-xs text-gray-600">
                            {dup.report.description.substring(0, 100)}...
                          </p>
                          
                          <div className="flex items-center gap-4 text-xs text-gray-500">
                            <span className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {formatDistance(dup.distance)}
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {getTimeSince(dup.report.dateFiled)}
                            </span>
                            <span className="flex items-center gap-1">
                              <FileText className="h-3 w-3" />
                              ID: {dup.report.id}
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      id="confirmNotDuplicate"
                      checked={confirmSubmitDuplicate}
                      onChange={(e) => setConfirmSubmitDuplicate(e.target.checked)}
                      className="mt-1"
                    />
                    <label htmlFor="confirmNotDuplicate" className="text-sm cursor-pointer">
                      <strong>I confirm this is NOT a duplicate report.</strong> I have reviewed the similar reports above and my issue is different or still unresolved.
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* Photo Upload */}
            <div className="space-y-2">
              <Label htmlFor="photo">Upload Photo (Optional)</Label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                {photoPreview ? (
                  <div className="space-y-3">
                    <img 
                      src={photoPreview} 
                      alt="Preview" 
                      className="max-h-64 mx-auto rounded-lg"
                    />
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        setPhotoPreview('');
                        setFormData(prev => ({ ...prev, photoFile: null }));
                      }}
                    >
                      Remove Photo
                    </Button>
                  </div>
                ) : (
                  <div>
                    <Upload className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                    <label htmlFor="photo" className="cursor-pointer">
                      <span className="text-blue-600 hover:text-blue-700">Click to upload</span>
                      <span className="text-gray-600"> or drag and drop</span>
                    </label>
                    <p className="text-xs text-gray-500 mt-2">PNG, JPG up to 5MB</p>
                    <input
                      id="photo"
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoChange}
                      className="hidden"
                    />
                  </div>
                )}
              </div>
              {errors.photo && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="h-3 w-3" />
                  {errors.photo}
                </p>
              )}
            </div>

            {/* Info Alert */}
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Your report will be reviewed by barangay officials and forwarded to appropriate authorities if needed.
                You'll receive notifications about status updates.
              </AlertDescription>
            </Alert>

            {/* Submit Button */}
            <div className="flex gap-3">
              <Button 
                type="submit" 
                className="flex-1 bg-blue-600 hover:bg-blue-700"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Submitting...' : 'Submit Report'}
              </Button>
              <Button 
                type="button" 
                variant="outline"
                onClick={onBack}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
