import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { Report, User } from '../types';
import { mockUsers, mockBarangayActions, mockEngineerActions } from '../lib/mockData';
import { MapPin, Calendar, FileText, User as UserIcon, Clock, ArrowLeft, Brain, Star, MessageSquare } from 'lucide-react';
import { MapView } from './MapView';
import { FeedbackDialog } from './FeedbackDialog';

interface ReportDetailsScreenProps {
  report: Report;
  currentUser: User;
  onBack: () => void;
}

export function ReportDetailsScreen({ report, currentUser, onBack }: ReportDetailsScreenProps) {
  const [feedbackDialogOpen, setFeedbackDialogOpen] = useState(false);
  const reporter = mockUsers.find(u => u.id === report.userId);
  const assignedUser = report.assignedTo ? mockUsers.find(u => u.id === report.assignedTo) : null;
  
  const barangayAction = mockBarangayActions.find(a => a.reportId === report.id);
  const engineerAction = mockEngineerActions.find(a => a.reportId === report.id);
  
  const isReporter = currentUser.id === report.userId;
  const canProvideFeedback = isReporter && report.status === 'Completed' && !report.feedback;

  const handleSubmitFeedback = (reportId: string, feedback: string, rating: number) => {
    report.feedback = feedback;
    report.feedbackRating = rating;
    report.feedbackDate = new Date();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Ongoing': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'Forwarded': return 'bg-purple-100 text-purple-800 border-purple-200';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'Severe':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'Moderate':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Minor':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Button variant="ghost" onClick={onBack} className="mb-4">
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back
      </Button>

      {/* Main Report Info */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap mb-2">
                <CardTitle>{report.id}</CardTitle>
                <Badge variant="outline" className={getStatusColor(report.status)}>
                  {report.status}
                </Badge>
                
                {/* Severity Badge - AI Automated (Read-only) */}
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className={getSeverityColor(report.severity)}>
                    {report.severity}
                  </Badge>
                  <Badge variant="outline" className="gap-1 text-xs">
                    <Brain className="h-3 w-3" />
                    AI Detected
                  </Badge>
                </div>
              </div>
              <p className="text-gray-600">{report.reportType}</p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Report Photo */}
          {report.photoUrl && (
            <div className="rounded-lg overflow-hidden border border-gray-200">
              <img 
                src={report.photoUrl} 
                alt="Report" 
                className="w-full h-64 sm:h-96 object-cover"
              />
            </div>
          )}

          {/* Description */}
          <div>
            <h3 className="flex items-center gap-2 mb-2">
              <FileText className="h-5 w-5 text-gray-600" />
              Description
            </h3>
            <p className="text-gray-700">{report.description}</p>
          </div>

          {/* AI Severity Detection Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <Brain className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="text-sm">
                  <strong>AI-Powered Severity Detection</strong>
                </p>
                <p className="text-sm text-gray-700">
                  The <strong>{report.severity}</strong> severity level was automatically determined by AI analysis based on the report description, location, type, and uploaded photo. Severity levels are locked and cannot be manually edited to ensure consistency and accuracy.
                </p>
                <p className="text-sm text-gray-600 mt-2">
                  {report.severity === 'Severe' ? (
                    <>• <strong>Severe reports</strong> are automatically routed to City Engineers only</>
                  ) : (
                    <>• <strong>Minor and Moderate reports</strong> are handled by Barangay Officials</>
                  )}
                </p>
              </div>
            </div>
          </div>

          <Separator />

          {/* Location */}
          <div>
            <h3 className="flex items-center gap-2 mb-3">
              <MapPin className="h-5 w-5 text-gray-600" />
              Location
            </h3>
            <p className="text-gray-700 mb-3">{report.location}</p>
            {report.latitude && report.longitude && (
              <>
                <p className="text-sm text-gray-500 mb-3">
                  Coordinates: {report.latitude}, {report.longitude}
                </p>
                <MapView 
                  reports={[report]} 
                  selectedReport={report}
                  height="300px"
                  showControls={false}
                />
              </>
            )}
          </div>

          <Separator />

          {/* Timeline */}
          <div>
            <h3 className="flex items-center gap-2 mb-2">
              <Calendar className="h-5 w-5 text-gray-600" />
              Timeline
            </h3>
            <div className="space-y-1 text-sm">
              <p className="text-gray-700">
                <span className="text-gray-500">Filed:</span> {report.dateFiled.toLocaleString()}
              </p>
              {report.dateResolved && (
                <p className="text-gray-700">
                  <span className="text-gray-500">Resolved:</span> {report.dateResolved.toLocaleString()}
                </p>
              )}
            </div>
          </div>

          <Separator />

          {/* Reporter Info */}
          <div>
            <h3 className="flex items-center gap-2 mb-3">
              <UserIcon className="h-5 w-5 text-gray-600" />
              Reporter Information
            </h3>
            {reporter && (
              <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-gray-500">Name:</span>
                    <p className="text-gray-700">{reporter.fullname}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Contact:</span>
                    <p className="text-gray-700">{reporter.contactNumber}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Email:</span>
                    <p className="text-gray-700">{reporter.email}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Address:</span>
                    <p className="text-gray-700">{reporter.address}</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Assigned To */}
          {assignedUser && (
            <>
              <Separator />
              <div>
                <h3 className="flex items-center gap-2 mb-3">
                  <UserIcon className="h-5 w-5 text-gray-600" />
                  Assigned To
                </h3>
                <div className="bg-blue-50 rounded-lg p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <span>{assignedUser.fullname}</span>
                    <Badge>{assignedUser.role}</Badge>
                  </div>
                  <p className="text-sm text-gray-600">{assignedUser.email}</p>
                </div>
              </div>
            </>
          )}

          {/* Feedback */}
          {report.feedback ? (
            <>
              <Separator />
              <div>
                <h3 className="flex items-center gap-2 mb-3">
                  <MessageSquare className="h-5 w-5 text-gray-600" />
                  Resident Feedback
                </h3>
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 space-y-3">
                  {/* Rating */}
                  {report.feedbackRating && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-600">Rating:</span>
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`h-4 w-4 ${
                              star <= report.feedbackRating!
                                ? 'fill-yellow-400 text-yellow-400'
                                : 'text-gray-300'
                            }`}
                          />
                        ))}
                        <span className="ml-2 text-sm">
                          ({report.feedbackRating}/5)
                        </span>
                      </div>
                    </div>
                  )}
                  {/* Feedback Text */}
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Comments:</p>
                    <p className="text-gray-700">{report.feedback}</p>
                  </div>
                  {/* Feedback Date */}
                  {report.feedbackDate && (
                    <p className="text-xs text-gray-500">
                      Submitted on: {report.feedbackDate.toLocaleString()}
                    </p>
                  )}
                </div>
              </div>
            </>
          ) : canProvideFeedback && (
            <>
              <Separator />
              <div>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <MessageSquare className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm mb-3">
                        <strong>This report has been completed!</strong> We'd love to hear your feedback about the resolution.
                      </p>
                      <Button 
                        onClick={() => setFeedbackDialogOpen(true)}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <Star className="h-4 w-4 mr-2" />
                        Provide Feedback
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Barangay Actions */}
      {barangayAction && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Barangay Official Action
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Action Date:</span>
                <span>{barangayAction.actionDate.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Status Update:</span>
                <Badge className={getStatusColor(barangayAction.status)}>
                  {barangayAction.status}
                </Badge>
              </div>
              <Separator />
              <div>
                <p className="text-sm text-gray-600 mb-2">Remarks:</p>
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-gray-700">{barangayAction.remarks}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Engineer Actions */}
      {engineerAction && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              City Engineer Action
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <span className="text-sm text-gray-600">Assigned Team:</span>
                  <p>{engineerAction.assignedTeam}</p>
                </div>
                <div>
                  <span className="text-sm text-gray-600">Priority Level:</span>
                  <Badge className="ml-2">{engineerAction.priority}</Badge>
                </div>
                <div>
                  <span className="text-sm text-gray-600">Status:</span>
                  <Badge className={`ml-2 ${getStatusColor(engineerAction.status)}`}>
                    {engineerAction.status}
                  </Badge>
                </div>
                {engineerAction.completionDate && (
                  <div>
                    <span className="text-sm text-gray-600">Completion Date:</span>
                    <p>{engineerAction.completionDate.toLocaleDateString()}</p>
                  </div>
                )}
              </div>
              <Separator />
              <div>
                <p className="text-sm text-gray-600 mb-2">Technical Assessment & Remarks:</p>
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-gray-700">{engineerAction.remarks}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Map Placeholder */}
      {report.latitude && report.longitude && (
        <Card>
          <CardHeader>
            <CardTitle>Location Map</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-100 rounded-lg p-12 text-center border-2 border-dashed border-gray-300">
              <MapPin className="h-16 w-16 mx-auto mb-4 text-gray-400" />
              <p className="text-gray-600 mb-2">
                Coordinates: {report.latitude}, {report.longitude}
              </p>
              <p className="text-sm text-gray-500">
                Interactive map would be displayed here in production
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Feedback Dialog */}
      {canProvideFeedback && (
        <FeedbackDialog
          open={feedbackDialogOpen}
          onClose={() => setFeedbackDialogOpen(false)}
          report={report}
          onSubmit={handleSubmitFeedback}
        />
      )}
    </div>
  );
}
