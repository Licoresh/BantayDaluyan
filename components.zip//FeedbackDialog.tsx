import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Star, MessageSquare } from 'lucide-react';
import { Report } from '../types';

interface FeedbackDialogProps {
  open: boolean;
  onClose: () => void;
  report: Report;
  onSubmit: (reportId: string, feedback: string, rating: number) => void;
}

export function FeedbackDialog({ open, onClose, report, onSubmit }: FeedbackDialogProps) {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [feedback, setFeedback] = useState('');

  const handleSubmit = () => {
    if (rating === 0) {
      alert('Please select a rating');
      return;
    }
    if (!feedback.trim()) {
      alert('Please provide feedback');
      return;
    }
    onSubmit(report.id, feedback, rating);
    setRating(0);
    setFeedback('');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-blue-600" />
            Provide Feedback
          </DialogTitle>
          <DialogDescription>
            How satisfied are you with the resolution of report <strong>{report.id}</strong>?
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Rating Section */}
          <div>
            <label className="text-sm mb-3 block">Rate your satisfaction:</label>
            <div className="flex items-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  className="transition-transform hover:scale-110"
                >
                  <Star
                    className={`h-8 w-8 ${
                      star <= (hoveredRating || rating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                </button>
              ))}
              {rating > 0 && (
                <span className="ml-2 text-sm text-gray-600">
                  {rating === 1 && 'Very Dissatisfied'}
                  {rating === 2 && 'Dissatisfied'}
                  {rating === 3 && 'Neutral'}
                  {rating === 4 && 'Satisfied'}
                  {rating === 5 && 'Very Satisfied'}
                </span>
              )}
            </div>
          </div>

          {/* Feedback Text */}
          <div>
            <label className="text-sm mb-2 block">
              Share your experience: <span className="text-red-500">*</span>
            </label>
            <Textarea
              placeholder="Please describe your experience with the resolution of this report..."
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              rows={5}
              className="resize-none"
            />
            <p className="text-xs text-gray-500 mt-1">
              Your feedback helps us improve our services
            </p>
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={rating === 0 || !feedback.trim()}
            className="bg-blue-600 hover:bg-blue-700"
          >
            Submit Feedback
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
