import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Calendar as CalendarComponent } from './ui/calendar';
import { Label } from './ui/label';
import { Report, ReportStatus, Severity } from '../types';
import { mockReports } from '../lib/mockData';
import { FileText, MapPin, Calendar, AlertTriangle, CheckCircle, MessageSquare, CalendarIcon, AlertCircle, Brain, Zap } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { MapView } from './MapView';
import { format } from 'date-fns';
import { determineBarangayPriority, getPriorityBadgeClass, getPriorityLabel } from '../lib/priorityAutomation';
import { getSeverityColor } from '../lib/severityDetection';

interface BarangayDashboardProps {
  userId: string;
  onViewReport: (report: Report) => void;
}

export function BarangayDashboard({ userId, onViewReport }: BarangayDashboardProps) {
  const [selectedReport, setSelectedReport] = useState<string | null>(null);
  const [remarks, setRemarks] = useState('');
  const [newStatus, setNewStatus] = useState<ReportStatus>('Ongoing');
  const [actionDate, setActionDate] = useState<Date | undefined>(new Date());
  const [autoPriority, setAutoPriority] = useState<{
    priority: number;
    priorityLabel: string;
    reasoning: string[];
    estimatedResponse: string;
  } | null>(null);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Barangay Officials only see Minor and Moderate severity reports
  const assignedReports = mockReports.filter(r => 
    (r.assignedTo === userId || r.status === 'Pending') && 
    (r.severity === 'Minor' || r.severity === 'Moderate')
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Ongoing': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'Forwarded': return 'bg-purple-100 text-purple-800 border-purple-200';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'Severe':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'Moderate':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Minor':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  // Auto-determine priority when report is selected
  useEffect(() => {
    if (selectedReport) {
      const report = assignedReports.find(r => r.id === selectedReport);
      if (report) {
        const analysis = determineBarangayPriority(report);
        setAutoPriority(analysis);
      }
    }
  }, [selectedReport]);

  const stats = {
    total: assignedReports.length,
    pending: assignedReports.filter(r => r.status === 'Pending').length,
    ongoing: assignedReports.filter(r => r.status === 'Ongoing').length,
    completed: assignedReports.filter(r => r.status === 'Completed').length
  };

  const handleUpdateReport = (reportId: string) => {
    // Validate inputs
    const errors: Record<string, string> = {};
    
    if (!remarks.trim()) {
      errors.remarks = 'Remarks are required';
    }
    
    if (!actionDate) {
      errors.actionDate = 'Action date is required';
    }
    
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      toast.error('Please fill in all required fields');
      return;
    }

    const priorityText = autoPriority ? autoPriority.priorityLabel : 'Medium';
    toast.success(`Report status updated to ${newStatus}`, {
      description: `Priority: ${priorityText} (Auto-assigned)`
    });
    
    // Reset form
    setSelectedReport(null);
    setRemarks('');
    setNewStatus('Ongoing');
    setActionDate(new Date());
    setAutoPriority(null);
    setFormErrors({});
  };



  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl">Barangay Reports Management</h2>
        <p className="text-gray-600">Review and manage assigned reports</p>
      </div>

      {/* Role-Based Access Info */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <Brain className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm">
              <strong>Barangay Official Access:</strong> You can view and manage <strong>Minor</strong> and <strong>Moderate</strong> severity reports. Severe cases are automatically routed to City Engineers.
            </p>
          </div>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Assigned</p>
                <p className="text-3xl mt-1">{stats.total}</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending Action</p>
                <p className="text-3xl mt-1">{stats.pending}</p>
              </div>
              <div className="bg-yellow-100 p-3 rounded-full">
                <AlertTriangle className="h-6 w-6 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">In Progress</p>
                <p className="text-3xl mt-1">{stats.ongoing}</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <Calendar className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Resolved</p>
                <p className="text-3xl mt-1">{stats.completed}</p>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Map View */}
      <Card>
        <CardHeader>
          <CardTitle>Reports Map - Iligan City</CardTitle>
        </CardHeader>
        <CardContent>
          <MapView 
            reports={assignedReports} 
            onReportClick={onViewReport}
            height="500px"
          />
        </CardContent>
      </Card>

      {/* Reports List */}
      <Card>
        <CardHeader>
          <CardTitle>Assigned Reports</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {assignedReports.map(report => (
              <div 
                key={report.id}
                className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-all"
              >
                <div className="flex flex-col lg:flex-row gap-4">
                  {/* Image */}
                  <div className="flex-shrink-0">
                    {report.photoUrl ? (
                      <img 
                        src={report.photoUrl} 
                        alt="Report" 
                        className="w-full lg:w-32 h-32 object-cover rounded-lg"
                      />
                    ) : (
                      <div className="w-full lg:w-32 h-32 bg-gray-100 rounded-lg flex items-center justify-center">
                        <FileText className="h-8 w-8 text-gray-400" />
                      </div>
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 space-y-3">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium">{report.id}</span>
                          <Badge variant="outline" className={getStatusColor(report.status)}>
                            {report.status}
                          </Badge>
                          <Badge variant="outline" className={getSeverityColor(report.severity)}>
                            {report.severity}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">
                          {report.reportType}
                        </p>
                      </div>
                    </div>

                    <p className="text-gray-700">{report.description}</p>

                    <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        {report.location}
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        Filed: {report.dateFiled.toLocaleDateString()}
                      </div>
                    </div>

                    {/* Action Section */}
                    {selectedReport === report.id ? (
                      <div className="bg-gray-50 p-4 rounded-lg space-y-3 mt-3">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {/* Action Date */}
                          <div className="space-y-2">
                            <Label htmlFor="action-date">
                              Action Date *
                            </Label>
                            <Popover>
                              <PopoverTrigger asChild>
                                <Button
                                  variant="outline"
                                  className={`w-full justify-start text-left ${
                                    formErrors.actionDate ? 'border-red-500' : ''
                                  }`}
                                >
                                  <CalendarIcon className="mr-2 h-4 w-4" />
                                  {actionDate ? format(actionDate, 'PPP') : 'Pick a date'}
                                </Button>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <CalendarComponent
                                  mode="single"
                                  selected={actionDate}
                                  onSelect={(date) => {
                                    setActionDate(date);
                                    setFormErrors(prev => ({ ...prev, actionDate: '' }));
                                  }}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            {formErrors.actionDate && (
                              <p className="text-sm text-red-600 flex items-center gap-1">
                                <AlertCircle className="h-3 w-3" />
                                {formErrors.actionDate}
                              </p>
                            )}
                          </div>

                          {/* Priority Level */}
                          {/* Automated Priority Analysis */}
                          {autoPriority && (
                            <div className="space-y-2">
                              <div className="flex items-center gap-2">
                                <Label>Automated Priority Assignment</Label>
                                <Badge variant="outline" className="gap-1">
                                  <Brain className="h-3 w-3" />
                                  AI
                                </Badge>
                              </div>
                              <div className={`border-2 rounded-lg p-4 ${
                                autoPriority.priority === 1 ? 'border-red-200 bg-red-50' :
                                autoPriority.priority === 2 ? 'border-orange-200 bg-orange-50' :
                                autoPriority.priority === 3 ? 'border-yellow-200 bg-yellow-50' :
                                'border-blue-200 bg-blue-50'
                              }`}>
                                <div className="space-y-2">
                                  <div className="flex items-center gap-2">
                                    <Badge className={getPriorityBadgeClass(autoPriority.priority)}>
                                      Priority {autoPriority.priority}: {autoPriority.priorityLabel}
                                    </Badge>
                                  </div>
                                  <p className="text-sm">{autoPriority.estimatedResponse}</p>
                                  <div className="mt-2 pt-2 border-t">
                                    <p className="text-xs mb-1">Analysis factors:</p>
                                    <ul className="text-xs space-y-1">
                                      {autoPriority.reasoning.slice(0, 3).map((reason, idx) => (
                                        <li key={idx} className="flex items-start gap-2">
                                          <span className="text-blue-600 mt-0.5">•</span>
                                          <span className="text-gray-700">{reason}</span>
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="status-update">Update Status</Label>
                          <Select value={newStatus} onValueChange={(v) => setNewStatus(v as ReportStatus)}>
                            <SelectTrigger id="status-update">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Ongoing">Ongoing</SelectItem>
                              <SelectItem value="Completed">Completed</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="remarks">Add Remarks *</Label>
                          <Textarea
                            id="remarks"
                            placeholder="Enter your inspection notes and action taken..."
                            value={remarks}
                            onChange={(e) => {
                              setRemarks(e.target.value);
                              setFormErrors(prev => ({ ...prev, remarks: '' }));
                            }}
                            rows={3}
                            className={formErrors.remarks ? 'border-red-500' : ''}
                          />
                          {formErrors.remarks && (
                            <p className="text-sm text-red-600 flex items-center gap-1">
                              <AlertCircle className="h-3 w-3" />
                              {formErrors.remarks}
                            </p>
                          )}
                        </div>

                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                          <p className="text-sm text-blue-800">
                            📋 Summary: Setting <strong>{newStatus}</strong> status with <strong>{autoPriority ? autoPriority.priorityLabel : 'Auto'}</strong> priority on <strong>{actionDate ? format(actionDate, 'MMM dd, yyyy') : 'N/A'}</strong>
                          </p>
                        </div>

                        <div className="flex gap-2">
                          <Button 
                            onClick={() => handleUpdateReport(report.id)}
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Submit Update
                          </Button>
                          <Button 
                            variant="outline"
                            onClick={() => {
                              setSelectedReport(null);
                              setRemarks('');
                              setActionDate(new Date());
                              setAutoPriority(null);
                              setFormErrors({});
                            }}
                          >
                            Cancel
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-wrap gap-2 mt-3">
                        <Button 
                          size="sm"
                          onClick={() => {
                            setSelectedReport(report.id);
                            setActionDate(new Date());
                            setRemarks('');
                            setNewStatus('Ongoing');
                            setFormErrors({});
                          }}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          <MessageSquare className="h-4 w-4 mr-2" />
                          Take Action
                        </Button>
                        <Button 
                          size="sm"
                          variant="outline"
                          onClick={() => onViewReport(report)}
                        >
                          View Full Details
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
