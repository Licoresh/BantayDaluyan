import React, { useEffect, useRef } from 'react';
import { Report } from '../types';
import { MapPin, Navigation } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';

interface MapViewProps {
  reports: Report[];
  selectedReport?: Report;
  onReportClick?: (report: Report) => void;
  height?: string;
  showControls?: boolean;
}

export function MapView({ 
  reports, 
  selectedReport, 
  onReportClick, 
  height = '400px',
  showControls = true 
}: MapViewProps) {
  const mapRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);

  useEffect(() => {
    // Only initialize map once
    if (mapRef.current) return;

    // Dynamically import Leaflet to avoid SSR issues
    import('leaflet').then((L) => {
      // Initialize map centered on Iligan City
      const map = L.map('map', {
        scrollWheelZoom: false, // Disable scroll wheel zoom to prevent hijacking page scroll
        zoomControl: true,
        dragging: true,
        doubleClickZoom: true,
        touchZoom: true
      }).setView([8.2280, 124.2452], 13);

      // Add OpenStreetMap tiles
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
      }).addTo(map);

      // Enable scroll wheel zoom when user clicks on the map
      map.on('click', function() {
        if (!map.scrollWheelZoom.enabled()) {
          map.scrollWheelZoom.enable();
        }
      });

      // Disable scroll wheel zoom when mouse leaves the map
      map.getContainer().addEventListener('mouseleave', function() {
        map.scrollWheelZoom.disable();
      });

      mapRef.current = map;

      // Add markers for each report
      reports.forEach((report) => {
        if (report.latitude && report.longitude) {
          // Define marker colors based on severity
          const color = 
            report.severity === 'Severe' ? '#DC2626' : 
            report.severity === 'Moderate' ? '#F59E0B' : 
            '#10B981';

          // Create custom icon
          const icon = L.divIcon({
            className: 'custom-marker',
            html: `
              <div style="
                background-color: ${color};
                width: 32px;
                height: 32px;
                border-radius: 50% 50% 50% 0;
                transform: rotate(-45deg);
                border: 3px solid white;
                box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                display: flex;
                align-items: center;
                justify-content: center;
              ">
                <div style="
                  transform: rotate(45deg);
                  color: white;
                  font-size: 16px;
                  font-weight: bold;
                ">📍</div>
              </div>
            `,
            iconSize: [32, 32],
            iconAnchor: [16, 32],
            popupAnchor: [0, -32],
          });

          const marker = L.marker([report.latitude, report.longitude], { icon })
            .addTo(map)
            .bindPopup(`
              <div style="min-width: 200px;">
                <strong>${report.id}</strong><br/>
                <span style="color: ${color};">● ${report.severity}</span><br/>
                <small>${report.reportType}</small><br/>
                <small>${report.location}</small><br/>
                <span style="
                  display: inline-block;
                  padding: 2px 8px;
                  margin-top: 4px;
                  border-radius: 4px;
                  font-size: 11px;
                  background-color: ${
                    report.status === 'Completed' ? '#D1FAE5' :
                    report.status === 'Ongoing' ? '#DBEAFE' :
                    report.status === 'Forwarded' ? '#E0E7FF' :
                    '#FEF3C7'
                  };
                  color: ${
                    report.status === 'Completed' ? '#065F46' :
                    report.status === 'Ongoing' ? '#1E40AF' :
                    report.status === 'Forwarded' ? '#3730A3' :
                    '#92400E'
                  };
                ">${report.status}</span>
              </div>
            `);

          marker.on('click', () => {
            if (onReportClick) {
              onReportClick(report);
            }
          });

          markersRef.current.push(marker);
        }
      });

      // If there's a selected report, center on it
      if (selectedReport && selectedReport.latitude && selectedReport.longitude) {
        map.setView([selectedReport.latitude, selectedReport.longitude], 16);
      }
    });

    return () => {
      // Cleanup
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
        markersRef.current = [];
      }
    };
  }, []);

  // Update selected report view
  useEffect(() => {
    if (mapRef.current && selectedReport && selectedReport.latitude && selectedReport.longitude) {
      mapRef.current.setView([selectedReport.latitude, selectedReport.longitude], 16);
    }
  }, [selectedReport]);

  return (
    <div className="relative z-0">
      <div id="map" style={{ height, width: '100%', borderRadius: '8px', position: 'relative', zIndex: 0 }}></div>
      
      {/* Legend */}
      {showControls && (
        <Card className="absolute bottom-4 left-4 p-3 bg-white/95 backdrop-blur z-10">
          <div className="space-y-2">
            <p className="text-xs mb-2 opacity-70">Severity Levels</p>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-600"></div>
              <span className="text-sm">Severe</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-amber-500"></div>
              <span className="text-sm">Moderate</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
              <span className="text-sm">Minor</span>
            </div>
          </div>
        </Card>
      )}
      
      {/* Report count badge */}
      {showControls && (
        <Badge className="absolute top-4 right-4 bg-blue-600 text-white z-10">
          <MapPin className="w-3 h-3 mr-1" />
          {reports.filter(r => r.latitude && r.longitude).length} Reports
        </Badge>
      )}

      {/* Scroll zoom hint */}
      {showControls && (
        <div className="absolute top-4 left-4 bg-blue-100/95 text-blue-800 text-xs px-3 py-2 rounded-md backdrop-blur z-10 max-w-[200px]">
          💡 Click map to enable scroll zoom
        </div>
      )}
    </div>
  );
}

// Add required CSS for Leaflet
if (typeof document !== 'undefined') {
  const style = document.createElement('style');
  style.textContent = `
    @import url('https://unpkg.com/leaflet@1.9.4/dist/leaflet.css');
    
    /* Ensure map doesn't overlap header */
    #map {
      z-index: 0 !important;
    }
    
    .leaflet-container {
      z-index: 0 !important;
    }
    
    .leaflet-pane {
      z-index: auto !important;
    }
    
    .leaflet-top,
    .leaflet-bottom {
      z-index: 10 !important;
    }
    
    .leaflet-control {
      z-index: 10 !important;
    }
    
    .leaflet-popup-pane {
      z-index: 20 !important;
    }
    
    .leaflet-tooltip-pane {
      z-index: 20 !important;
    }
    
    .custom-marker {
      background: transparent;
      border: none;
    }
    
    .leaflet-popup-content-wrapper {
      border-radius: 8px;
    }
    
    .leaflet-popup-content {
      margin: 12px;
    }
  `;
  document.head.appendChild(style);
}
