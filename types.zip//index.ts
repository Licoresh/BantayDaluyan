export type UserRole = 'Resident' | 'Barangay Official' | 'City Engineer' | 'Admin';

export type ReportStatus = 'Pending' | 'Ongoing' | 'Completed' | 'Forwarded';

export type ReportType = 'Drainage' | 'Flooding' | 'Garbage' | 'Others';

export type Severity = 'Minor' | 'Moderate' | 'Severe';

export interface User {
  id: string;
  fullname: string;
  email: string;
  password: string;
  contactNumber: string;
  address: string;
  role: UserRole;
  createdAt: Date;
}

export interface Report {
  id: string;
  userId: string;
  reportType: ReportType;
  description: string;
  location: string;
  latitude: number;
  longitude: number;
  severity: Severity;
  photoUrl?: string;
  status: ReportStatus;
  dateFiled: Date;
  dateResolved?: Date;
  assignedTo?: string;
  priority?: number;
  feedback?: string;
  feedbackRating?: number;
  feedbackDate?: Date;
}

export interface BarangayAction {
  id: string;
  reportId: string;
  officialId: string;
  remarks: string;
  actionDate: Date;
  status: ReportStatus;
}

export interface CityEngineerAction {
  id: string;
  reportId: string;
  engineerId: string;
  assignedTeam: string;
  remarks: string;
  completionDate?: Date;
  status: ReportStatus;
  priority: number;
}

export interface Notification {
  id: string;
  userId: string;
  reportId: string;
  message: string;
  isRead: boolean;
  createdAt: Date;
}

export interface ActivityLog {
  id: string;
  userId: string;
  action: string;
  reportId?: string;
  timestamp: Date;
  details: string;
}
